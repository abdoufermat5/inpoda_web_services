import json

from zeep import Client

client = Client('http://localhost:8000/?wsdl')

if __name__ == '__main__':
    json_file = open('../data/versailles_tweets_100.json', encoding="UTF-8")
    json_str = json_file.read()
    json_data = json.loads(json_str)
    print("len", len(json_data))
    topic = "<->".join(
        [topic["domain"].get("name", "General") for topic in json_data[2].get("context_annotations", [])])
    json_data[2]["topic"] = topic
    for res in client.service.getTopKHashTag(3):
        print(res)
