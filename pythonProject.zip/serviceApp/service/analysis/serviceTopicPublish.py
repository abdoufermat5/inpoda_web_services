from spyne import ServiceBase, Unicode, Iterable, rpc

from model.Tweet import Tweet


class ServiceTopicPublish(ServiceBase):
    @rpc(Unicode, _returns=Iterable(Unicode))
    def publishByTopic(ctx, topic):
        tweets = ctx.udc.session.query(Tweet).filter_by(topic=topic).all()
        yield f"Found {len(tweets)} tweets with topic {topic}"
        for t in tweets:
            yield t.text
